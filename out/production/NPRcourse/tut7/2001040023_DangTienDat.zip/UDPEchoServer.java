package tut7;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class UDPEchoServer {
    public static void main(String args[]) throws Exception {
        int port = 9876;
        DatagramSocket serverSocket = new DatagramSocket(port);
        System.out.println("Server is running...");
        //byte[] receiveData = new byte[1024];
        //byte[] sendData  = new byte[1024];

        while(true) {
            byte[] receiveData = new byte[1024];
            byte[] sendData    = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket (receiveData, receiveData.length);
            serverSocket.receive(receivePacket);
            String sentence = new String(receivePacket.getData());
            sentence = sentence.trim();
            double number = Double.parseDouble(sentence);
            System.out.println("Message from client: "+sentence);

            // Calculate the cube of the number
            double cube = Math.pow(number, 3);
            String cubeValue = Double.toString(cube);
            sendData = cubeValue.getBytes();

            InetAddress clientAddress = receivePacket.getAddress();
            int clientPort = receivePacket.getPort();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            serverSocket.send(sendPacket);


        }
    }

}
