package tut6;

import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) throws IOException {
        String serverAddress = "localhost";
        int serverPort = 9876;

        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));

        Socket clientSocket = new Socket(serverAddress, serverPort);
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        try {
            System.out.print("Enter an integer number: ");
            int n = Integer.parseInt(userInput.readLine());
            out.println(n);

            String response = in.readLine();
            System.out.println("Square of " + n + " received from server: " + response);
        } finally {
            out.close();
            in.close();
            userInput.close();
            clientSocket.close();
        }
    }
}
