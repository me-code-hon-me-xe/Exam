package tut6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class TCPServer {
    public static void main(String[] args) throws IOException {
        int port = 9876;
        ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Server is running...");

        while (true){
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connected: "+ clientSocket.getInetAddress());

            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            try{
                String inputLine = in.readLine();
                int n = Integer.parseInt(inputLine);
                int square = n*n;
                out.println(square);
                System.out.println("Square of " + n + " sent to client.");
            }finally {
                in.close();
                out.close();
                clientSocket.close();
            }

        }
    }
}
